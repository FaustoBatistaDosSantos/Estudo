﻿namespace Calculadora.Strategy
{
    public interface ICalcularStrategy
    {
        double Operacao(double v1, double v2);
    }
}