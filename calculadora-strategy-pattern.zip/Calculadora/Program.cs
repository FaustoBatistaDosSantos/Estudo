﻿using Calculadora.Concrets;
using Calculadora.Context;
using System;

namespace Calculadora
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args is null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            CalculadoraContext calculadora = new();

            while (true)
            {
                Console.WriteLine("Informe o primeiro valor");
                double valor1 = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Informe o segundo valor");
                double valor2 = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("-------------------------------");
                Console.WriteLine("1 - Somar");
                Console.WriteLine("2 - Subtrair");
                Console.WriteLine("3 - Dividir");
                Console.WriteLine("4 - Multiplicar");

                string opcao = Console.ReadLine();

                switch (opcao)
                {
                    case "1":
                        calculadora.SetStrategy(new Somar());
                        calculadora.CalcularOperacao(valor1, valor2);
                        break;
                    case "2":
                        calculadora.SetStrategy(new Subtrair());
                        calculadora.CalcularOperacao(valor1, valor2);
                        break;
                    case "3":
                        calculadora.SetStrategy(new Dividir());
                        calculadora.CalcularOperacao(valor1, valor2);
                        break;
                    case "4":
                        calculadora.SetStrategy(new Multiplicar());
                        calculadora.CalcularOperacao(valor1, valor2);
                        break;
                    default:
                        break;
                }
            }
        }
    }
}