﻿using Calculadora.Strategy;
using System;

namespace Calculadora.Context
{
    public class CalculadoraContext
    {
        private ICalcularStrategy _calcular;

        public CalculadoraContext()
        {

        }

        public CalculadoraContext(ICalcularStrategy calcular)
        {
            _calcular = calcular;
        }

        public void SetStrategy(ICalcularStrategy strategy)
        {
            _calcular = strategy;
        }

        public void CalcularOperacao(double v1, double v2)
        {
            var result = _calcular.Operacao(v1, v2);
            Console.WriteLine(result);
        }
    }
}