﻿using Calculadora.Strategy;

namespace Calculadora.Concrets
{
    public class Subtrair : ICalcularStrategy
    {
        public double Operacao(double v1, double v2)
        {
            return v1 - v2;
        }
    }
}